/*
Group Members
Name :Olyad Mulugeta 
ID:1102901
SEC:B
Name :Michale Belachw
ID:1101883
SEC:B
Name :Tadios Anteneh
ID:1102080
SEC:B
*/
package projectmanagment2;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author user
 */
public class Projectmanagment2 extends Application {
   
   @Override
    public void start(Stage primaryStage) throws Exception{
    login login=new login();
     login.start(primaryStage);

        /*Scene scene=new Scene(login,800,500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("student project managment");
        primaryStage.setMaximized(true);
        primaryStage.show();

         */
    }

   
    public static void main(String[] args) {
        launch(args);
    }
    
}
