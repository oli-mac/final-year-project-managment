/*
Group Members
Name :Olyad Mulugeta 
ID:1102901
SEC:B
Name :Michale Belachw
ID:1101883
SEC:B
Name :Tadios Anteneh
ID:1102080
SEC:B
*/
package projectmanagment2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.swing.text.TabableView;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javax.swing.JOptionPane;

public class homepage extends Application {

    @Override
    public void start(Stage PrimaryStage) throws Exception,FileNotFoundException,EOFException{
 Label lblmaster = new Label("FINAL PROJECT MANAGMENT SYSTEM FOR GRADUATING STUDENTS",new ImageView(new Image("projectmanagment2/bdu_1.jpg")));
        lblmaster.setContentDisplay(ContentDisplay.LEFT);
        lblmaster.setScaleX(1);
        lblmaster.setScaleY(1);
        lblmaster.setTextFill(Color.web("#FFFFFF"));
        BorderPane master =new BorderPane();
        
        //search HBOX
        HBox sea= new HBox(15);
        sea.setAlignment(Pos.TOP_RIGHT);
        
        Button logout =new Button("logout");

        //logout button==========
        logout.setOnAction(event -> {
            login logs=new login();
            try {
                logs.start(PrimaryStage);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        sea.getChildren().addAll(logout);
        master.setTop(sea);
        master.setBottom(lblmaster);
        //=====================================
        TabPane tab=new TabPane();
        Tab tab1=new Tab("Student Registration");
        Tab tab2=new Tab("Adv Registration");
        Tab tab3=new Tab("Project Registration");
        Tab tab4=new Tab("search ");
        
        Tab tabgroup=new Tab("Group Registration");
        tab.getTabs().addAll(tab1,tab2,tab3,tabgroup,tab4);
        master.setCenter(tab);


        //STUDENT REGISTRATION TAB=====================================================
       
        VBox stdbox= new VBox(10);
        stdbox.setAlignment(Pos.CENTER);
        stdbox.setPadding(new Insets(5,5,5,5));
        //THE FIRST H BOX
        HBox A= new HBox(15);
        A.setAlignment(Pos.CENTER);
        Label idlabel = new Label("ID :");
        TextField idtextfild= new TextField();
        A.getChildren().addAll(idlabel,idtextfild);
        //2ND HBOX
        HBox B= new HBox(15);
        B.setAlignment(Pos.CENTER);
        Label fnamelbl = new Label("Full name :");
        TextField fnametext= new TextField();
        B.getChildren().addAll(fnamelbl,fnametext);
        //3RD HBOX
        HBox C= new HBox(15);
        C.setAlignment(Pos.CENTER);
        Label slbl5= new Label("gender :");
        Label male= new Label("male");
        Label female= new Label("female");
        RadioButton rdm=new RadioButton();
        RadioButton rdf=new RadioButton();
        ToggleGroup tt=new ToggleGroup();
        rdm.setToggleGroup(tt);
        rdf.setToggleGroup(tt);
        C.getChildren().addAll(slbl5,rdm,male,rdf,female);
        //4ND HBOX
        HBox D= new HBox(15);
        D.setAlignment(Pos.CENTER);
        Label deplable = new Label("department :");
        TextField deptext= new TextField();
        D.getChildren().addAll(deplable,deptext);

        //6TH HBOX
        HBox E= new HBox(15);
        E.setAlignment(Pos.CENTER);
        Label yearlbl = new Label("year :");
        TextField yeartext= new TextField();
        E.getChildren().addAll(yearlbl,yeartext);
        //7TH HBOX
        HBox F= new HBox(15);
        F.setAlignment(Pos.CENTER);
        Label cgpalbl = new Label("CGPA :");
        TextField cgpatext= new TextField();
        F.getChildren().addAll(cgpalbl,cgpatext);
       
        Button submits =new Button("submit");
        
        

        submits.setOnAction(event -> {

             String gender=null;
            if(rdm.isSelected()){
                gender="male";
            }else if(rdf.isSelected()){
                gender="female";
            }
            String db_driver="com.mysql.cj.jdbc.Driver";
            Connection conection=null;
            String con_string="jdbc:mysql://localhost/projectmanagment";


            try {
                Class.forName(db_driver);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            try {
                conection=DriverManager.getConnection(con_string,"root","");
            } catch (SQLException e) {
                e.printStackTrace();
            }


            String insert_stud_quary="INSERT INTO `student`(`id`, `name`, `gender`, `department`, `year`, `cgpa`) VALUES ('"+idtextfild.getText()+"','"+fnametext.getText()+"','"+gender+"','"+deptext.getText()+"','"+yeartext.getText()+"','"+cgpatext.getText()+"')";

            Statement stmt=null;

            try {
                stmt=conection.createStatement();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                stmt.executeUpdate(insert_stud_quary);
            } catch (SQLException e) {
                e.printStackTrace();
            }

                JOptionPane.showMessageDialog(null, "succsecfully added student");
                idtextfild.setText("");
                fnametext.setText("");
                deptext.setText("");
                yeartext.setText("");
                cgpatext.setText("");
                
        });

        
        //========================================================================



        //ADVISOR REGISTRATION TAB=====================================================

        VBox advbox= new VBox(10);
        advbox.setAlignment(Pos.CENTER);
        advbox.setPadding(new Insets(5,5,5,5));
        //THE FIRST H BOX
        
        HBox L= new HBox(15);
        L.setAlignment(Pos.CENTER);
        Label albl1 = new Label("ID :");
        TextField advoid= new TextField();
        L.getChildren().addAll(albl1,advoid);
        //2ND hbox
        HBox M= new HBox(15);
        M.setAlignment(Pos.CENTER);
        Label albl2 = new Label("Full Name :");
        TextField advname= new TextField();
        M.getChildren().addAll(albl2,advname);
        //3ND hbox
        HBox N= new HBox(15);
        N.setAlignment(Pos.CENTER);
        Label albl3 = new Label("Qualification: ");
        TextField qualtext= new TextField();
        N.getChildren().addAll(albl3,qualtext);
        //4ND hbox
        HBox P= new HBox(15);
        P.setAlignment(Pos.CENTER);
        Label albl5 = new Label("Specification :");
        TextField spectxt= new TextField();
        P.getChildren().addAll(albl5,spectxt);
        Button submita =new Button("submit");
        submita.setOnAction(event -> {
        String gender=null;
        
            String db_driver="com.mysql.cj.jdbc.Driver";
            Connection conection=null;
            String con_string="jdbc:mysql://localhost/projectmanagment";


            try {
                Class.forName(db_driver);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            try {
                conection=DriverManager.getConnection(con_string,"root","");
            } catch (SQLException e) {
                e.printStackTrace();
            }


            String insert_stud_quary="INSERT INTO `advisor`(`id`, `name`, `qualification`, `specification`) VALUES ('"+advoid.getText()+"','"+advname.getText()+"','"+qualtext.getText()+"','"+spectxt.getText()+"')";

            Statement stmt=null;

            try {
                stmt=conection.createStatement();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                stmt.executeUpdate(insert_stud_quary);
            } catch (SQLException e) {
                e.printStackTrace();
            }

        JOptionPane.showMessageDialog(null, "succsecfully added advisor");
        advoid.setText("");
        advname.setText("");
        spectxt.setText("");
        qualtext.setText("");
        });

        //========================================================================


        //PROJECT REGISTRATION TAB=====================================================
        VBox probox= new VBox(10);
        probox.setAlignment(Pos.CENTER);
        probox.setPadding(new Insets(5,5,5,5));
        //THE FIRST H BOX
        HBox H= new HBox(15);
        H.setAlignment(Pos.CENTER);
        Label plbl1 = new Label("Title :");
        TextField titetext= new TextField();
        H.getChildren().addAll(plbl1,titetext);
        //2ND HBOX
        HBox I= new HBox(15);
        I.setAlignment(Pos.CENTER);
        Label plbl2 = new Label("Discription :");
        TextArea desctxt= new TextArea();
        desctxt.setPrefRowCount(7);
        desctxt.setPrefColumnCount(20);
        I.getChildren().addAll(plbl2,desctxt);
        //3RD HBOX
        HBox J= new HBox(15);
        J.setAlignment(Pos.CENTER);
        Label plbl3 = new Label("Filed of study :");
        TextField fildtxt= new TextField();
        J.getChildren().addAll(plbl3,fildtxt);
        //4rth
        HBox K= new HBox(15);
        K.setAlignment(Pos.CENTER);
        Label plbl4 = new Label("Advisor name :");
        TextField advstxt= new TextField();
        K.getChildren().addAll(plbl4,advstxt);

        Button submitP =new Button("submit");
        submitP.setOnAction(event -> {
        String gender=null;
        
            String db_driver="com.mysql.cj.jdbc.Driver";
            Connection conection=null;
            String con_string="jdbc:mysql://localhost/projectmanagment";


            try {
                Class.forName(db_driver);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            try {
                conection=DriverManager.getConnection(con_string,"root","");
            } catch (SQLException e) {
                e.printStackTrace();
            }


            String insert_stud_quary="INSERT INTO `project`(`title`, `discription`, `filed`, `advisor`) VALUES ('"+titetext.getText()+"','"+desctxt.getText()+"','"+fildtxt.getText()+"','"+advstxt.getText()+"')";

            Statement stmt=null;

            try {
                stmt=conection.createStatement();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                stmt.executeUpdate(insert_stud_quary);
            } catch (SQLException e) {
                e.printStackTrace();
            }

        JOptionPane.showMessageDialog(null, "sucssefully added project");
        titetext.setText("");
        desctxt.setText("");
        fildtxt.setText("");
        advstxt.setText("");
        
        
        });

        //========================================================================
        //group tab===========================================================
        VBox groupbox= new VBox(10);
        groupbox.setAlignment(Pos.CENTER);
        groupbox.setPadding(new Insets(5,5,5,5));
       //1st hbox
        HBox Z= new HBox(15);
        Z.setAlignment(Pos.CENTER);
        Label groupidl= new Label("group number:");
        TextField groptxt =new TextField();
        Z.getChildren().addAll(groupidl,groptxt);
        //2nd
        HBox U= new HBox(15);
        U.setAlignment(Pos.CENTER);
        Label groupnamel= new Label("group name");
        TextField groupntxt =new TextField();
        U.getChildren().addAll(groupnamel,groupntxt);
        //3rd
        HBox V= new HBox(15);
        V.setAlignment(Pos.CENTER);
        Label stud1= new Label("1st student name");
        TextField stdtxt1 =new TextField();
        V.getChildren().addAll(stud1,stdtxt1);
        //4rt
        HBox Y= new HBox(15);
        Y.setAlignment(Pos.CENTER);
        Label stdl= new Label("2nd student name");
        TextField stdtxt2 =new TextField();
        Y.getChildren().addAll(stdl,stdtxt2);
        //5th
        HBox YY= new HBox(15);
        YY.setAlignment(Pos.CENTER);
        Label stdlb= new Label("3rd student name");
        TextField stdtxt3 =new TextField();
        YY.getChildren().addAll(stdlb,stdtxt3);
        Button submitg =new Button("submit");
        submitg.setOnAction(event -> {

             String gender=null;
            if(rdm.isSelected()){
                gender="male";
            }else if(rdf.isSelected()){
                gender="female";
            }
            String db_driver="com.mysql.cj.jdbc.Driver";
            Connection conection=null;
            String con_string="jdbc:mysql://localhost/projectmanagment";


            try {
                Class.forName(db_driver);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            try {
                conection=DriverManager.getConnection(con_string,"root","");
            } catch (SQLException e) {
                e.printStackTrace();
            }


            String insert_stud_quary="INSERT INTO `group`(`group number`,`name`, `student1`, `student2`, `student3`) VALUES ('"+groptxt.getText()+"','"+groupntxt.getText()+"','"+stdtxt1.getText()+"','"+stdtxt2.getText()+"','"+stdtxt3.getText()+"')";

            Statement stmt=null;

            try {
                stmt=conection.createStatement();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                stmt.executeUpdate(insert_stud_quary);
            } catch (SQLException e) {
                e.printStackTrace();
            }


            JOptionPane.showMessageDialog(null, "succsecfully added group");
            groptxt.setText("");
            groupntxt.setText("");
            stdtxt1.setText("");
            stdtxt2.setText("");
            stdtxt3.setText("");
            
        });
        
        
        
        //===================================================
        
        
        //search tab=============================================
        VBox searchbox= new VBox(15);
        groupbox.setAlignment(Pos.CENTER);
        groupbox.setPadding(new Insets(20,20,20,20));
        searchbox.setAlignment(Pos.CENTER);
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(10);
        gridPane.setHgap(10);
        HBox searching= new HBox(15);
        searching.setAlignment(Pos.CENTER);
        TextField search2= new TextField();
        Button searches =new Button("search");
        
        searching.getChildren().addAll(search2,searches);
        HBox delet= new HBox(15);
        delet.setAlignment(Pos.CENTER);
        Button delete =new Button("delete");
        Button done =new Button("Done");
        delet.getChildren().addAll(delete,done);
        
        Label lbl1 = new Label("");
        Label lbl2 = new Label("");
        Label lbl3 = new Label("");
        ComboBox seachfrom =new ComboBox();
        seachfrom.getItems().add("student");
        seachfrom.getItems().add("advisor");
        seachfrom.getItems().add("project");
        seachfrom.getItems().add("group");
        seachfrom.setValue("search from");
        
        Label sid= new Label("");
        Label stid= new Label();
        Label sname= new Label("");
        Label stname= new Label();
        Label sgender= new Label("");
        Label stgender= new Label();
        Label sdep= new Label("");
        Label stdep= new Label();
        Label syear= new Label("");
        Label styear= new Label();
        Label scgpa= new Label("");
        Label stcgpa= new Label();
        gridPane.addColumn(0, sid, sname, sgender, sdep,syear,scgpa);
        gridPane.addColumn(1, stid, stname, stgender, stdep,styear,stcgpa);
        
        searches.setOnAction(event -> {
        //search in the student table
            if(seachfrom.getValue().toString()=="student") {
            sid.setText("ID");
            sname.setText("Full name");
            sgender.setText("Gender");
            sdep.setText("department");
            syear.setText("year");
            scgpa.setText("CGPA");
                 try {
            String qu="SELECT `id`, `name`, `gender`, `department`,`year`,`cgpa` FROM `student` WHERE name='"+search2.getText().toString()+"'";
            String db_driver="com.mysql.cj.jdbc.Driver";
            Connection conection=null;
            String con_string="jdbc:mysql://localhost/projectmanagment";
            try {
                Class.forName(db_driver);
            } catch (ClassNotFoundException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            try {
                conection=DriverManager.getConnection(con_string,"root","");
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            ResultSet rs = null;
            try {
                rs = conection.createStatement().executeQuery(qu);
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            while(rs.next()){

                try {
                
                    stid.setText(rs.getString("id"));
                    stname.setText(rs.getString("name"));
                    stgender.setText(rs.getString("gender"));
                    stdep.setText(rs.getString("department"));
                    styear.setText(rs.getString("year"));
                    stcgpa.setText(rs.getString("cgpa"));
                    
                } catch (SQLException ex) {
                    Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
                }
            }



        } catch (SQLException ex) {
                       Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
               }

        //search in advisor table========================================== 
            
        }if(seachfrom.getValue().toString()=="advisor") {
            
                 try {
            sid.setText("advisorid");
            sname.setText("advsor name");
            sgender.setText("qualification");
            sdep.setText("specification");
            syear.setText("");
            scgpa.setText("");
      
            String qu="SELECT `id`, `name`, `qualification`, `specification` FROM `advisor` WHERE name='"+search2.getText().toString()+"'";
            String db_driver="com.mysql.cj.jdbc.Driver";
            Connection conection=null;
            String con_string="jdbc:mysql://localhost/projectmanagment";
            try {
                Class.forName(db_driver);
            } catch (ClassNotFoundException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            try {
                conection=DriverManager.getConnection(con_string,"root","");
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            ResultSet rs = null;
            try {
                rs = conection.createStatement().executeQuery(qu);
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            while(rs.next()){

                try {
                
                    stid.setText(rs.getString("id"));
                    stname.setText(rs.getString("name"));
                    stgender.setText(rs.getString("qualification"));
                    stdep.setText(rs.getString("specification"));
                    
                    
                } catch (SQLException ex) {
                    Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
                }
            }



        } catch (SQLException ex) {
                       Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
               }

            
            //search in the group table======================================================
                  }if(seachfrom.getValue().toString()=="group") {
            
                 try {
            sid.setText("group number");
            sname.setText("group name");
            sgender.setText("student1");
            sdep.setText("student2");
            syear.setText("student3");
            scgpa.setText("");
      
            String qu="SELECT `group number`, `name`,`student1`, `student2`, `student3` FROM `group` WHERE name='"+search2.getText().toString()+"'";
            String db_driver="com.mysql.cj.jdbc.Driver";
            Connection conection=null;
            String con_string="jdbc:mysql://localhost/projectmanagment";
            try {
                Class.forName(db_driver);
            } catch (ClassNotFoundException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            try {
                conection=DriverManager.getConnection(con_string,"root","");
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            ResultSet rs = null;
            try {
                rs = conection.createStatement().executeQuery(qu);
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            while(rs.next()){

                try {
                
                    stid.setText(rs.getString("group number"));
                    stname.setText(rs.getString("name"));
                    stgender.setText(rs.getString("student1"));
                    stdep.setText(rs.getString("student2"));
                    styear.setText(rs.getString("student3"));
                    
                    
                } catch (SQLException ex) {
                    Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
                }
            }



        } catch (SQLException ex) {
                       Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
               }

            //project search======================================================
            
                  }if(seachfrom.getValue().toString()=="project") {
            
                 try {
            sid.setText("title");
            sname.setText("discription");
            sgender.setText("filed");
            sdep.setText("advisor");
            syear.setText("");
            scgpa.setText("");
      
            String qu="SELECT `title`, `discription`,`filed`, `advisor` FROM `project` WHERE title='"+search2.getText().toString()+"'";
            String db_driver="com.mysql.cj.jdbc.Driver";
            Connection conection=null;
            String con_string="jdbc:mysql://localhost/projectmanagment";
            try {
                Class.forName(db_driver);
            } catch (ClassNotFoundException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            try {
                conection=DriverManager.getConnection(con_string,"root","");
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            ResultSet rs = null;
            try {
                rs = conection.createStatement().executeQuery(qu);
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            while(rs.next()){

                try {
                
                    stid.setText(rs.getString("title"));
                    stname.setText(rs.getString("discription"));
                    stgender.setText(rs.getString("filed"));
                    stdep.setText(rs.getString("advisor"));
                    
                    
                    
                } catch (SQLException ex) {
                    Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
                }
            }



        } catch (SQLException ex) {
                       Logger.getLogger(homepage.class.getName()).log(Level.SEVERE, null, ex);
               }

            
            
                  }});
        //===================================================delet advisor
          
        
                delete.setOnAction(event -> {
                     if(seachfrom.getValue().toString()=="advisor") {
                String db_driver="com.mysql.cj.jdbc.Driver";
                 Connection conection=null;
                 String con_string="jdbc:mysql://localhost/projectmanagment";
                String dbqu="DELETE FROM `advisor` WHERE name='"+search2.getText().toString()+"'";
                                                try {
                        Class.forName(db_driver);
                        conection=DriverManager.getConnection(con_string,"root","");
                        Statement stmt=null;
                        stmt=conection.createStatement();
                        stmt.executeUpdate(dbqu);
                                                } catch (ClassNotFoundException e1) {
                                                        // TODO Auto-generated catch block
                                                        e1.printStackTrace();
                                                } catch (SQLException e1) {
                                                        // TODO Auto-generated catch block
                                                        e1.printStackTrace();
                                                }

                JOptionPane.showMessageDialog(null, "sucssefully deleted Advisor");
                     stid.setText("");
                    stname.setText("");
                    stgender.setText("");
                    stdep.setText("");
                    styear.setText("");
                    stcgpa.setText("");

//delet from student====================================
                     } if(seachfrom.getValue().toString()=="student") {
                String db_driver="com.mysql.cj.jdbc.Driver";
                 Connection conection=null;
                 String con_string="jdbc:mysql://localhost/projectmanagment";
                String dbqu="DELETE FROM `student` WHERE name='"+search2.getText().toString()+"'";
                                                try {
                        Class.forName(db_driver);
                        conection=DriverManager.getConnection(con_string,"root","");
                        Statement stmt=null;
                        stmt=conection.createStatement();
                        stmt.executeUpdate(dbqu);
                                                } catch (ClassNotFoundException e1) {
                                                        // TODO Auto-generated catch block
                                                        e1.printStackTrace();
                                                } catch (SQLException e1) {
                                                        // TODO Auto-generated catch block
                                                        e1.printStackTrace();
                                                }

                JOptionPane.showMessageDialog(null, "sucssefully deleted Student");
                     stid.setText("");
                    stname.setText("");
                    stgender.setText("");
                    stdep.setText("");
                    styear.setText("");
                    stcgpa.setText("");


                     }
//delet project=============================================================                     
                     if(seachfrom.getValue().toString()=="project") {
                String db_driver="com.mysql.cj.jdbc.Driver";
                 Connection conection=null;
                 String con_string="jdbc:mysql://localhost/projectmanagment";
                String dbqu="DELETE FROM `project` WHERE title='"+search2.getText().toString()+"'";
                                                try {
                        Class.forName(db_driver);
                        conection=DriverManager.getConnection(con_string,"root","");
                        Statement stmt=null;
                        stmt=conection.createStatement();
                        stmt.executeUpdate(dbqu);
                                                } catch (ClassNotFoundException e1) {
                                                        // TODO Auto-generated catch block
                                                        e1.printStackTrace();
                                                } catch (SQLException e1) {
                                                        // TODO Auto-generated catch block
                                                        e1.printStackTrace();
                                                }

                JOptionPane.showMessageDialog(null, "sucssefully deleted Project");
                     stid.setText("");
                    stname.setText("");
                    stgender.setText("");
                    stdep.setText("");
                    styear.setText("");
                    stcgpa.setText("");


                     }
//delet from group=============================================================
                     if(seachfrom.getValue().toString()=="group") {
                String db_driver="com.mysql.cj.jdbc.Driver";
                 Connection conection=null;
                 String con_string="jdbc:mysql://localhost/projectmanagment";
                String dbqu="DELETE FROM `group` WHERE 	name='"+search2.getText().toString()+"'";
                                                try {
                        Class.forName(db_driver);
                        conection=DriverManager.getConnection(con_string,"root","");
                        Statement stmt=null;
                        stmt=conection.createStatement();
                        stmt.executeUpdate(dbqu);
                                                } catch (ClassNotFoundException e1) {
                                                        // TODO Auto-generated catch block
                                                        e1.printStackTrace();
                                                } catch (SQLException e1) {
                                                        // TODO Auto-generated catch block
                                                        e1.printStackTrace();
                                                }

                JOptionPane.showMessageDialog(null, "sucssefully deleted Group");
                     stid.setText("");
                    stname.setText("");
                    stgender.setText("");
                    stdep.setText("");
                    styear.setText("");
                    stcgpa.setText("");


                     }
      
                
                });
                
                
    //done button======================================================
       
        done.setOnAction(event -> {
          JOptionPane.showMessageDialog(null, "Good Bye");
          login dogs=new login();
            try {
                dogs.start(PrimaryStage);
            } catch (Exception e) {
                e.printStackTrace();
            }});
        
        
        //=====================================================
        searchbox.getChildren().addAll(lbl1,seachfrom,lbl3,searching,gridPane,delet);
        tab4.setContent(searchbox);
        stdbox.getChildren().addAll(A,B,C,D,E,F,submits);
        tab1.setContent(stdbox);
        advbox.getChildren().addAll(L,M,N,P,submita);
        tab2.setContent(advbox);
        probox.getChildren().addAll(H,I,J,K,submitP);
        tab3.setContent(probox);
        groupbox.getChildren().addAll(Z,U,V,Y,YY,submitg);
        tabgroup.setContent(groupbox);
        master.setStyle("-fx-background-color:gray");
        tab.setStyle("-fx-background-image:url('projectmanagment2/bdblur.jpg');"
                + "-fx-background-postion:center center;"
               + "-fx-background-repeat:stretch;" );
        //
        //tab.setStyle("-fx-background-color:white");
        Scene scene=new Scene(master,1360,735);
        PrimaryStage.setScene(scene);
        PrimaryStage.setTitle("student project managment");
        PrimaryStage.setMaximized(true);
        PrimaryStage.show();


    }
}

