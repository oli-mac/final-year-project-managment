project managment software for final year students
defult user name: admin
defult password:admin

Group Members
Name :Olyad Mulugeta 
ID:1102901
SEC:B
Name :Michale Belachw
ID:1101883
SEC:B
Name :Tadios Anteneh
ID:1102080
SEC:B