/*
Group Members
Name :Olyad Mulugeta 
ID:1102901
SEC:B
Name :Michale Belachw
ID:1101883
SEC:B
Name :Tadios Anteneh
ID:1102080
SEC:B
*/
package projectmanagment2;
import javafx.application.Application;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import static javafx.scene.paint.Color.color;
import static javafx.scene.paint.Color.color;
import javafx.stage.Stage;

public class login extends Application {
     String admin ="admin";
     String adminp ="admin";

    @Override
    public  void start(Stage primaryStage) throws Exception {
            
      
           
           
        VBox login= new VBox(10);
        login.setAlignment(Pos.CENTER);
        login.setPadding(new Insets(5,5,5,5)); 
       Label labeled = new Label("FINAL PROJECT MANAGMENT SYSTEM FOR GRADUATING STUDENTS"); 
       labeled.setScaleX(2);
        labeled.setScaleY(2);
        labeled.setAlignment(Pos.TOP_RIGHT);
        Label well = new Label("Enter User Name and Password to Continue");
        well.setScaleX(1.5);
        well.setScaleY(1.5);
        ImageView imag= new ImageView(new Image("projectmanagment2/bdu.jpg"));
        imag.setFitHeight(200);
        imag.setFitWidth(200);
        login.setStyle("-fx-background-image:url('projectmanagment2/bdblur.jpg');"
                + "-fx-background-postion:center;"
                );
       
        HBox user= new HBox(15);
        user.setAlignment(Pos.CENTER);
        Label ulbl1 = new Label("User name");
        TextField utf1= new TextField();
        user.getChildren().addAll(ulbl1,utf1);
        //use=utf1.getText();
        //password
        HBox password= new HBox(15);
        password.setAlignment(Pos.CENTER);
        Label plbl1 = new Label("Password");
        PasswordField pass=new PasswordField();
        user.getChildren().addAll(plbl1,pass);
        Button loginbut =new Button("login");
       
        loginbut.setOnAction(event -> {
            if(utf1.getText().equals(admin) && pass.getText().equals(adminp)) {
                homepage home = new homepage();
                try {

                    home.start(primaryStage);
                    primaryStage.setMaximized(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            else{
             well.setTextFill(Color.web("#FF0000"));
              well.setText(" Wrong User name and Password !!");
              
            }
        });
        login.getChildren().addAll(labeled,well,imag,user,password,loginbut);
        

        Scene scene=new Scene(login,1360,735);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Student Project Managment");
        primaryStage.setMaximized(true);
        primaryStage.show();
    }
}